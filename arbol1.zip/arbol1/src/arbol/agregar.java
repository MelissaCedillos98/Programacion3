/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbol;

import javax.swing.JOptionPane;

/**
 *
 * @Melissa 
 */
public class agregar {

    public agregar() {
        
        int Arbol;  
        int Familia1;
        int Familia2;
        String fin;  
        fin="";  
        Arbol= 50;
        Familia1 = 10;
        Familia2 = 10;
        
    do{  
        
        String opcion = JOptionPane.showInputDialog(null," ¿Que deseas realizar:" + " \n " + " 1= Agregar a Familia 1 " + " \n " + " 2= Agregar a Famiia 2" + " \n " + "3= Salir");  
        int op;  
        op = Integer.parseInt(opcion);  

        
        switch(op) {  
        
            case 1:  
            
                String abonar = JOptionPane.showInputDialog(null,"¿Cuatos arboles quieres agrear?");  
                double mas;  
                mas = Integer.parseInt(abonar);  
                JOptionPane.showMessageDialog(null,"La cantidad de arboles que hay es de:"+(Familia1+mas));  
               
            break;  

            case 2:  
                
                String Agregar = JOptionPane.showInputDialog(null,"¿Cuatos arboles quieres agrear?");  
                double Mas;  
                Mas = Integer.parseInt(Agregar);  
                JOptionPane.showMessageDialog(null,"La cantidad de arboles que hay es de:"+(Familia1+Mas));   
         
            break;  

            case 3:  
            
                 JOptionPane.showMessageDialog(null,"Gracias por usar este programa.");  
                 System.exit(0);
            
                break;  
        }  
                JOptionPane.showInputDialog("¿Deseas hacer otra operación?" + " \n " + " 1= si" + " \n " + " 2= no");  
                //fin = Integer.parseInt(decision);  
    }while (fin=="");  
    
    arbol();
        
    }

    private void arbol() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
