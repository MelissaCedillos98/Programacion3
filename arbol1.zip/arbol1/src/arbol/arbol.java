/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbol;
import javax.swing.JOptionPane;

/**
 *
 * @Melissa
 */
public class arbol {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here}
        int Arbol;  
        String fin;  
        fin="";  
        Arbol= 50;
        
    do{  
        
        String opcion = JOptionPane.showInputDialog(null," ¿Que deseas realizar:" + " \n " + " 1= Agregar un arbol " + " \n " + " 2= Mostrar Catalogo" + " \n " + "3= Salir");  
        int op;  
        op = Integer.parseInt(opcion);  

        
        switch(op) {  
        
            case 1:  
            
                agregar Mas = new agregar();
                Agregar();
                
            break;  

            case 2:  
                
                 mostrar Catalogo = new mostrar(); 
                 Mostrar();
                 
         
            break;  

            case 3:  
            
                 JOptionPane.showMessageDialog(null,"Gracias por usar este programa.");  
                 System.exit(0);
            
                break;  
        }  
                JOptionPane.showInputDialog("¿Deseas hacer otra operación?" + " \n " + " 1= si" + " \n " + " 2= no");  
                //fin = Integer.parseInt(decision);  
    }while (fin=="");  
                
                 
    }

    private static void Mostrar() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static void Agregar() {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
