/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbol;

import javax.swing.JOptionPane;

/**
 *
 * @Melissa
 */
public class mostrar {

    public mostrar() {
        
        int Arbol;  
        int Familia1;
        int Familia2;
        String fin;  
        fin="";  
        Arbol= 50;
        Familia1 = 10;
        Familia2 = 10;
        
    do{  
        
        String opcion = JOptionPane.showInputDialog(null," ¿Que deseas realizar:" + " \n " + " 1= Mostrar Familia 1 " + " \n " + " 2= Mostrar Famiia 2" + " \n " + "3= Salir");  
        int op;  
        op = Integer.parseInt(opcion);  

        
        switch(op) {  
        
            case 1:  
                
                JOptionPane.showMessageDialog(null,"Familia 1");
                JOptionPane.showMessageDialog(null,"La cantidad de arboles que hay es de: "+(Familia1)+" Arboles");
               
            break;  

            case 2:  
                 
                JOptionPane.showMessageDialog(null,"Familia 2");
                JOptionPane.showMessageDialog(null,"La cantidad de arboles que hay es de: "+(Familia2)+" Arboles");   
         
            break;  

            case 3:  
            
                 JOptionPane.showMessageDialog(null,"Gracias por usar este programa.");  
                 System.exit(0);
            
                break;  
        }  
                JOptionPane.showInputDialog("¿Deseas hacer otra operación?" + " \n " + " 1= si" + " \n " + " 2= no");  
                //fin = Integer.parseInt(decision);  
    }while (fin=="");  
   
    }
   
}

